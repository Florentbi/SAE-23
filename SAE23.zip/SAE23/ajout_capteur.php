<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = $_POST['nom_capteur'];
    $type = $_POST['type_capteur'];
    $unite = $_POST['unite'];
    $id = $_POST['id_salle'];

    // Connexion à la base de données
    $conn = new mysqli("localhost", "root", "passroot", "sae23");
    if ($conn->connect_error) {
        die("Erreur de connexion : " . $conn->connect_error);
    }

    $stmt_capt = $conn->prepare("INSERT INTO Capteurs (NOM_cpt, type, unite, NOM_salle) VALUES (?, ?, ?, ?)");
    $stmt_capt->bind_param("ssss", $nom, $type, $unite, $id);

    if ($stmt_capt->execute()) {
        echo "<p>Capteur ajouté avec succès.</p>";
    } else {
        echo "<p>Erreur lors de l'ajout du capteur : " . $stmt_capt->error . "</p>";
    }

    $stmt_capt->close();
    $conn->close();
} else {
    echo "<p>Requête invalide.</p>";
}
?>
