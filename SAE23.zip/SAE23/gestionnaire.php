<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.gc_maxlifetime', 31536000);
    session_set_cookie_params(31536000);
    session_start();
}
if (!isset($_SESSION['gestionnaire'])) {
    header("Location: login_gestionnaire.php");
    exit();
}
$login = $_SESSION['gestionnaire'];

$conn = mysqli_connect("localhost", "root", "passroot", "sae23");

$statsQuery = "
    SELECT 
        c.NOM_cpt,
        MIN(m.valeur) AS min_val,
        MAX(m.valeur) AS max_val,
        AVG(m.valeur) AS avg_val
    FROM Capteurs c
    JOIN Mesure m ON c.NOM_cpt = m.NOM_cpt
    GROUP BY c.NOM_cpt
";
$statsResult = mysqli_query($conn, $statsQuery);

$measuresQuery = "
    SELECT 
        m.NOM_cpt, 
        m.date, 
        m.horaire, 
        m.valeur 
    FROM Mesure m
    ORDER BY m.date DESC, m.horaire DESC
    LIMIT 40
";
$measuresResult = mysqli_query($conn, $measuresQuery);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Gestionnaire - SAÉ23</title>
  <link rel="stylesheet" href="style/styles.css">
  <link rel="stylesheet" href="style/tableau.css">
  <meta http-equiv="refresh" content="15"> <!-- Rafraîchissement auto -->
</head>
<body>
  <header>
    <h1>Espace Gestionnaire</h1>
    <nav>
      <ul>
        <li><a href="index.html">Accueil</a></li>
        <li><a href="consultation.php">Consultation</a></li>
        <li><a href="gestionnaire.php">Gestion</a></li>
        <li><a href="admin.php">Administration</a></li>
		<li><a href="projet.html">Projet</a></li>
        <li><a href="logout.php">Déconnexion</a></li>
      </ul>
    </nav>
  </header>
  
	<main>
    <h2>Statistiques des Capteurs</h2>
    <table>
      <tr>
        <th>Nom du Capteur</th>
        <th>Valeur Min</th>
        <th>Valeur Max</th>
        <th>Valeur Moyenne</th>
      </tr>
      <?php while ($stat = mysqli_fetch_assoc($statsResult)): ?>
      <tr>
        <td><?= htmlspecialchars($stat['NOM_cpt']) ?></td>
        <td><?= $stat['min_val'] ?></td>
        <td><?= $stat['max_val'] ?></td>
        <td><?= round($stat['avg_val'], 2) ?></td>
      </tr>
      <?php endwhile; ?>
    </table>

    <h2>Mesures des Capteurs</h2>
    <table>
      <tr>
        <th>Nom du Capteur</th>
        <th>Date</th>
        <th>Heure</th>
        <th>Valeur</th>
      </tr>
      <?php while ($measure = mysqli_fetch_assoc($measuresResult)): ?>
      <tr>
        <td><?= htmlspecialchars($measure['NOM_cpt']) ?></td>
        <td><?= $measure['date'] ?></td>
        <td><?= $measure['horaire'] ?></td>
        <td><?= $measure['valeur'] ?></td>
      </tr>
      <?php endwhile; ?>
    </table>
  </main>
  
  <footer>
    <p>&copy; 2025 - SAÉ23 - IUT de Blagnac | <a href="mentions_legales.html">Mentions légales</a></p>
  </footer>
</body>
</html>

