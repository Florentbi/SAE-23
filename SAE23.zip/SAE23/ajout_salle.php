<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = $_POST['nom_salle'];
    $type = $_POST['type'];
    $capacite = $_POST['capacite'];
    $id = $_POST['id_batiment'];

    // Connexion à la base de données
    $conn = new mysqli("localhost", "root", "passroot", "sae23");
    if ($conn->connect_error) {
        die("Erreur de connexion : " . $conn->connect_error);
    }

    $stmt_salle = $conn->prepare("INSERT INTO Salle (NOM_salle, type, capacite, Identifiant) VALUES (?, ?, ?, ?)");
    $stmt_salle->bind_param("ssii", $nom, $type, $capacite, $id);

    if ($stmt_salle->execute()) {
        echo "<p>Salle ajouté avec succès.</p>";
    } else {
        echo "<p>Erreur lors de l'ajout de la salle : " . $stmt_salle->error . "</p>";
    }

    $stmt_salle->close();
    $conn->close();
} else {
    echo "<p>Requête invalide.</p>";
}
?>
