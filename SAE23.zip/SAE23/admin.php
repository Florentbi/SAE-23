<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
	ini_set('duree_session', 3600);
    session_start();
}

if (!isset($_SESSION['admin'])) {
    header("Location: login_administrateur.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Administration - SAÉ23</title>
  <link rel="stylesheet" type="text/css" href="style/styles.css">
</head>
<body>
  <header>
    <h1>Espace Administrateur</h1>
    <nav>
      <ul>
        <li><a href="index.html">Accueil</a></li>
        <li><a href="consultation.php">Consultation</a></li>
        <li><a href="gestionnaire.php">Gestion</a></li>
        <li><a href="admin.php">Administration</a></li>
        <li><a href="projet.html">Projet</a></li>
		<li><a href="logout.php">Se déconnecter</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section>
      <h2>Gestion des bâtiments, salles et capteurs</h2>
      <form method="post" action="ajout_batiment.php">
        <h3>Ajouter un bâtiment</h3>
        <input type="text" name="nom_batiment" placeholder="Nom du bâtiment" required>
		<input type="text" name="login" placeholder="login du gestionnaire" required>
		<input type="text" name="mdp" placeholder="mot de passe du gestionnaire" required>
        <input type="submit" value="Ajouter">
      </form>

      <form method="post" action="ajout_salle.php">
        <h3>Ajouter une salle</h3>
        <input type="text" name="nom_salle" placeholder="Nom de la salle" required>
        <input type="text" name="type" placeholder="Type de salle" required>
        <input type="number" name="capacite" placeholder="Capacité" required>
        <input type="number" name="id_batiment" placeholder="ID bâtiment" required>
        <input type="submit" value="Ajouter">
      </form>

      <form method="post" action="ajout_capteur.php">
        <h3>Ajouter un capteur</h3>
        <input type="text" name="nom_capteur" placeholder="Nom du capteur" required>
        <input type="text" name="type_capteur" placeholder="Type" required>
        <input type="text" name="unite" placeholder="Unité" required>
        <input type="text" name="id_salle" placeholder="ID salle" required>
        <input type="submit" value="Ajouter">
      </form>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 - SAÉ23 - IUT de Blagnac | <a href="mentions_legales.html">Mentions légales</a></p>
  </footer>
</body>
</html>

