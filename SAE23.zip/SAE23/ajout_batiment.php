<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = $_POST['nom_batiment'];
    $login = $_POST['login'];
    $password = $_POST['mdp'];

    // Connexion à la base de données
    $conn = new mysqli("localhost", "root", "passroot", "sae23");
    if ($conn->connect_error) {
        die("Erreur de connexion : " . $conn->connect_error);
    }

    $stmt_bat = $conn->prepare("INSERT INTO Batiment (nom, login, motdepasse) VALUES (?, ?, ?)");
    $stmt_bat->bind_param("sss", $nom, $login, $password);

    if ($stmt_bat->execute()) {
        echo "<p>Bâtiment ajouté avec succès.</p>";
    } else {
        echo "<p>Erreur lors de l'ajout du bâtiment : " . $stmt_bat->error . "</p>";
    }

    $stmt_bat->close();
    $conn->close();
} else {
    echo "<p>Requête invalide.</p>";
}
?>
