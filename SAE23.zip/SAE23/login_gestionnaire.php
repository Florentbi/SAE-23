<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $login = $_POST['login'];
    $password = $_POST['password'];

    $conn = mysqli_connect("localhost", "root", "passroot", "sae23");
    if ($conn->connect_error) die("Erreur de connexion : " . $conn->connect_error);

    $stmt = $conn->prepare("SELECT * FROM Batiment WHERE login = ? AND motdepasse = ?");
    $stmt->bind_param("ss", $login, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $_SESSION['gestionnaire'] = $login;
        header("Location: gestionnaire.php");
        exit();
    } else {
        $error = "Identifiants incorrects ou type incorrect.";
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Connexion Gestionnaire</title>
  <link rel="stylesheet" type="text/css" href="style/styles.css">
</head>
<body>
  <main>
    <h1>Connexion Gestionnaire</h1>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form method="post">
      <input type="text" name="login" placeholder="Identifiant" required><br>
      <input type="password" name="password" placeholder="Mot de passe" required><br>
      <input type="submit" value="Connexion">
    </form>
  </main>
</body>
</html>
