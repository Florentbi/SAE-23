<?php
ini_set('session.gc_maxlifetime', 31536000);
session_set_cookie_params(31536000);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['admin'])) {
    header("Location: login_admin.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="refresh" content="10">
  <title>Consultation - SAÉ23</title>
  <link rel="stylesheet" type="text/css" href="style/styles.css">
  <link rel="stylesheet" type="text/css" href="style/tableau.css">
</head>
<body>
  <header>
    <h1>Consultation des dernières mesures</h1>
    <nav>
      <ul>
        <li><a href="index.html">Accueil</a></li>
        <li><a href="consultation.php">Consultation</a></li>
        <li><a href="gestionnaire.php">Gestion</a></li>
        <li><a href="admin.php">Administration</a></li>
        <li><a href="projet.html">Projet</a></li>
      </ul>
    </nav>
  </header>

<main>
    <section>
      <h2>Dernières mesures de tous les capteurs</h2>
      <table>
        <thead>
          <tr>
            <th>Capteur</th>
            <th>Salle</th>
            <th>Date</th>
            <th>Heure</th>
            <th>Valeur</th>
            <th>Unité</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $conn = mysqli_connect("localhost", "root", "passroot", "sae23");
          if ($conn->connect_error) die("Erreur de connexion : " . $conn->connect_error);
		  mysqli_query($conn, "SET NAMES 'utf8'");
		  
          $sql = "
            SELECT c.NOM_cpt AS capteur, s.NOM_salle AS salle, m.date, m.horaire, m.valeur, c.unite
            FROM sae23.Mesure m
            JOIN (
              SELECT NOM_cpt, MAX(CONCAT(date, ' ', horaire)) AS max_datetime
              FROM sae23.Mesure
              GROUP BY NOM_cpt
            ) last_measures
            ON m.NOM_cpt = last_measures.NOM_cpt AND CONCAT(m.date, ' ', m.horaire) = last_measures.max_datetime
            JOIN sae23.Capteurs c ON m.NOM_cpt = c.NOM_cpt
            JOIN sae23.Salle s ON c.NOM_salle = s.NOM_salle
            ORDER BY m.date DESC, m.horaire DESC
          ";

          $result = $conn->query($sql);
          if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
              echo "<tr>
                      <td>{$row['capteur']}</td>
                      <td>{$row['salle']}</td>
                      <td>{$row['date']}</td>
                      <td>{$row['horaire']}</td>
                      <td>{$row['valeur']}</td>
                      <td>{$row['unite']}</td>
                    </tr>";
            }
          } else {
            echo "<tr><td colspan='6'>Aucune donnée trouvée</td></tr>";
          }
          $conn->close();
          ?>
        </tbody>
      </table>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 - SAÉ23 - IUT de Blagnac | <a href="mentions_legales.html">Mentions légales</a></p>
  </footer>
</body>
</html>
